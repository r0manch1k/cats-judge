#define  IDI_SYSINFO        100
#define  IDC_SYSINFO        101
#define  IDM_MENU           102
#define  IDD_ABOUTBOX       103
#define  IDR_MENUBAR        104
#define  IDS_HELP           105
#define  IDS_COMMAND1       301
#define  IDM_MAIN_COMMAND1  40001
#define  IDM_HELP_ABOUT     40003
#define  IDM_QUIT           40004
#define  IDM_MENUITEM40005  40005
#define  IDM_MENUITEM40006  40006


#define  I_IMAGENONE        -2

#define     TBSTYLE_DROPDOWN 0x0008
#define     TBSTYLE_AUTOSIZE 0x0010

